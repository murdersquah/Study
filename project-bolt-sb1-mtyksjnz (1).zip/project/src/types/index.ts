export interface User {
  id: string;
  email: string;
  name: string;
  currentSemester?: string;
}

export interface Semester {
  id: string;
  name: string;
  subjects: Subject[];
  createdAt: Date;
}

export interface Subject {
  id: string;
  name: string;
  color: string;
  examDate?: Date;
  modules: Module[];
  syllabus?: string;
  progress: number;
}

export interface Module {
  id: string;
  name: string;
  topics: Topic[];
  progress: number;
}

export interface Topic {
  id: string;
  name: string;
  completed: boolean;
  notes?: string;
  completedAt?: Date;
}

export interface StudySession {
  id: string;
  topicId: string;
  duration: number; // in minutes
  type: 'study' | 'break';
  completedAt: Date;
}

export interface DailyPlan {
  date: string;
  topics: string[]; // topic IDs
  completed: string[];
  pomodoroCount: number;
}

export interface PomodoroSettings {
  studyDuration: number;
  shortBreak: number;
  longBreak: number;
  ambientSound: 'none' | 'lofi' | 'rain' | 'cafe' | 'whitenoise';
}

export interface UserStats {
  totalTopicsCompleted: number;
  weeklyPomodoros: number;
  currentStreak: number;
  longestStreak: number;
  badges: string[];
}