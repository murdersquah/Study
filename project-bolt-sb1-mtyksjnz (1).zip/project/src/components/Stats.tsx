import React from 'react';
import { 
  TrendingUp, 
  Award, 
  Target,
  Clock,
  Calendar,
  BookOpen,
  CheckCircle
} from 'lucide-react';
import { Subject, UserStats } from '../types';

interface StatsProps {
  subjects: Subject[];
  stats: UserStats;
}

export default function Stats({ subjects, stats }: StatsProps) {
  const totalTopics = subjects.reduce((acc, subject) => 
    acc + subject.modules.reduce((modAcc, module) => modAcc + module.topics.length, 0), 0
  );
  
  const completedTopics = subjects.reduce((acc, subject) => 
    acc + subject.modules.reduce((modAcc, module) => 
      modAcc + module.topics.filter(topic => topic.completed).length, 0
    ), 0
  );

  const weeklyData = [
    { day: 'Mon', topics: 5, pomodoros: 8 },
    { day: 'Tue', topics: 3, pomodoros: 6 },
    { day: 'Wed', topics: 7, pomodoros: 12 },
    { day: 'Thu', topics: 4, pomodoros: 7 },
    { day: 'Fri', topics: 6, pomodoros: 10 },
    { day: 'Sat', topics: 8, pomodoros: 14 },
    { day: 'Sun', topics: 2, pomodoros: 4 },
  ];

  const badges = [
    { id: 'first-topic', name: 'First Steps', description: 'Complete your first topic', earned: completedTopics > 0 },
    { id: 'streak-3', name: 'Consistency', description: '3 days in a row', earned: stats.currentStreak >= 3 },
    { id: 'streak-7', name: 'Weekly Warrior', description: '7 days in a row', earned: stats.currentStreak >= 7 },
    { id: 'topics-50', name: 'Half Century', description: 'Complete 50 topics', earned: completedTopics >= 50 },
    { id: 'topics-100', name: 'Centurion', description: 'Complete 100 topics', earned: completedTopics >= 100 },
    { id: 'pomodoro-master', name: 'Focus Master', description: '100 pomodoros completed', earned: stats.weeklyPomodoros >= 100 },
  ];

  const maxTopics = Math.max(...weeklyData.map(d => d.topics));
  const maxPomodoros = Math.max(...weeklyData.map(d => d.pomodoros));

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Your Progress</h1>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <CheckCircle className="w-8 h-8 text-green-500" />
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{completedTopics}</p>
              <p className="text-sm text-gray-500">Topics Completed</p>
            </div>
          </div>
          <div className="bg-gray-100 rounded-full h-2">
            <div 
              className="bg-green-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${totalTopics > 0 ? (completedTopics / totalTopics) * 100 : 0}%` }}
            />
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <Clock className="w-8 h-8 text-orange-500" />
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{stats.weeklyPomodoros}</p>
              <p className="text-sm text-gray-500">This Week</p>
            </div>
          </div>
          <p className="text-xs text-gray-600">≈ {(stats.weeklyPomodoros * 25 / 60).toFixed(1)} hours focused</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <TrendingUp className="w-8 h-8 text-blue-500" />
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{stats.currentStreak}</p>
              <p className="text-sm text-gray-500">Current Streak</p>
            </div>
          </div>
          <p className="text-xs text-gray-600">Best: {stats.longestStreak} days</p>
        </div>

        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <Award className="w-8 h-8 text-purple-500" />
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{badges.filter(b => b.earned).length}</p>
              <p className="text-sm text-gray-500">Badges Earned</p>
            </div>
          </div>
          <p className="text-xs text-gray-600">out of {badges.length} total</p>
        </div>
      </div>

      {/* Weekly Progress Chart */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Weekly Activity</h2>
        <div className="grid grid-cols-7 gap-4">
          {weeklyData.map((day, index) => (
            <div key={day.day} className="text-center">
              <div className="mb-2">
                <div className="bg-gray-100 rounded-lg p-3 h-32 flex flex-col justify-end">
                  <div 
                    className="bg-blue-500 rounded mb-1 transition-all duration-500"
                    style={{ height: `${(day.topics / maxTopics) * 60}px` }}
                  />
                  <div 
                    className="bg-orange-500 rounded transition-all duration-500"
                    style={{ height: `${(day.pomodoros / maxPomodoros) * 40}px` }}
                  />
                </div>
              </div>
              <p className="text-xs font-medium text-gray-700">{day.day}</p>
              <p className="text-xs text-gray-500">{day.topics}t, {day.pomodoros}p</p>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center mt-4 space-x-6">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-blue-500 rounded mr-2" />
            <span className="text-sm text-gray-600">Topics</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-orange-500 rounded mr-2" />
            <span className="text-sm text-gray-600">Pomodoros</span>
          </div>
        </div>
      </div>

      {/* Subject Performance */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Subject Performance</h2>
        <div className="space-y-4">
          {subjects.map((subject) => {
            const subjectTopics = subject.modules.reduce((acc, mod) => acc + mod.topics.length, 0);
            const subjectCompleted = subject.modules.reduce((acc, mod) => 
              acc + mod.topics.filter(t => t.completed).length, 0
            );
            
            return (
              <div key={subject.id} className="border border-gray-100 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <div 
                      className="w-3 h-3 rounded-full mr-3"
                      style={{ backgroundColor: subject.color }}
                    />
                    <h3 className="font-medium text-gray-900">{subject.name}</h3>
                  </div>
                  <span className="text-sm font-medium text-gray-600">
                    {subjectCompleted}/{subjectTopics}
                  </span>
                </div>
                <div className="bg-gray-100 rounded-full h-2">
                  <div 
                    className="h-2 rounded-full transition-all duration-500"
                    style={{ 
                      width: `${subjectTopics > 0 ? (subjectCompleted / subjectTopics) * 100 : 0}%`,
                      backgroundColor: subject.color 
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Badges */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Achievements</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {badges.map((badge) => (
            <div 
              key={badge.id}
              className={`p-4 rounded-lg border transition-all duration-200 ${
                badge.earned
                  ? 'bg-yellow-50 border-yellow-200'
                  : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-center mb-2">
                <Award className={`w-6 h-6 mr-2 ${badge.earned ? 'text-yellow-600' : 'text-gray-400'}`} />
                <h3 className={`font-medium ${badge.earned ? 'text-gray-900' : 'text-gray-500'}`}>
                  {badge.name}
                </h3>
              </div>
              <p className={`text-sm ${badge.earned ? 'text-gray-700' : 'text-gray-500'}`}>
                {badge.description}
              </p>
              {badge.earned && (
                <div className="mt-2">
                  <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                    Earned
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}