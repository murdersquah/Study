import React from 'react';
import { 
  BookOpen, 
  Clock, 
  TrendingUp, 
  Calendar,
  Target,
  Award,
  CheckCircle,
  Timer
} from 'lucide-react';
import { Subject, UserStats } from '../types';

interface DashboardProps {
  subjects: Subject[];
  stats: UserStats;
  onNavigate: (page: string) => void;
}

export default function Dashboard({ subjects, stats, onNavigate }: DashboardProps) {
  const totalTopics = subjects.reduce((acc, subject) => 
    acc + subject.modules.reduce((modAcc, module) => modAcc + module.topics.length, 0), 0
  );
  
  const completedTopics = subjects.reduce((acc, subject) => 
    acc + subject.modules.reduce((modAcc, module) => 
      modAcc + module.topics.filter(topic => topic.completed).length, 0
    ), 0
  );

  const overallProgress = totalTopics > 0 ? (completedTopics / totalTopics) * 100 : 0;

  const upcomingExams = subjects
    .filter(subject => subject.examDate)
    .sort((a, b) => new Date(a.examDate!).getTime() - new Date(b.examDate!).getTime())
    .slice(0, 3);

  const getDaysUntilExam = (examDate: Date) => {
    const today = new Date();
    const exam = new Date(examDate);
    const diffTime = exam.getTime() - today.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Welcome back!</h1>
        <p className="text-blue-100 mb-4">
          You've completed {completedTopics} out of {totalTopics} topics
        </p>
        <div className="bg-white/20 rounded-lg p-1">
          <div 
            className="bg-white rounded-md h-2 transition-all duration-500 ease-out"
            style={{ width: `${overallProgress}%` }}
          />
        </div>
        <p className="text-sm text-blue-100 mt-2">{overallProgress.toFixed(1)}% complete</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition-all duration-200">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 text-green-500" />
            <span className="text-2xl font-bold text-gray-900">{completedTopics}</span>
          </div>
          <p className="text-sm text-gray-600">Topics Done</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition-all duration-200">
          <div className="flex items-center justify-between mb-2">
            <Timer className="w-8 h-8 text-orange-500" />
            <span className="text-2xl font-bold text-gray-900">{stats.weeklyPomodoros}</span>
          </div>
          <p className="text-sm text-gray-600">This Week</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition-all duration-200">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-blue-500" />
            <span className="text-2xl font-bold text-gray-900">{stats.currentStreak}</span>
          </div>
          <p className="text-sm text-gray-600">Day Streak</p>
        </div>

        <div className="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-md transition-all duration-200">
          <div className="flex items-center justify-between mb-2">
            <Award className="w-8 h-8 text-purple-500" />
            <span className="text-2xl font-bold text-gray-900">{stats.badges.length}</span>
          </div>
          <p className="text-sm text-gray-600">Badges</p>
        </div>
      </div>

      {/* Subject Progress */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Subject Progress</h2>
        <div className="space-y-4">
          {subjects.map((subject) => (
            <div key={subject.id} className="border border-gray-100 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-3"
                    style={{ backgroundColor: subject.color }}
                  />
                  <h3 className="font-medium text-gray-900">{subject.name}</h3>
                </div>
                <span className="text-sm font-medium text-gray-600">
                  {subject.progress.toFixed(0)}%
                </span>
              </div>
              <div className="bg-gray-100 rounded-full h-2">
                <div 
                  className="h-2 rounded-full transition-all duration-500 ease-out"
                  style={{ 
                    width: `${subject.progress}%`,
                    backgroundColor: subject.color 
                  }}
                />
              </div>
              {subject.examDate && (
                <p className="text-xs text-gray-500 mt-2">
                  Exam in {getDaysUntilExam(subject.examDate)} days
                </p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-4">
        <button
          onClick={() => onNavigate('planner')}
          className="bg-white rounded-xl border border-gray-100 p-6 text-left hover:shadow-md transition-all duration-200 group"
        >
          <Calendar className="w-8 h-8 text-blue-500 mb-3 group-hover:scale-110 transition-transform duration-200" />
          <h3 className="font-semibold text-gray-900 mb-1">Today's Plan</h3>
          <p className="text-sm text-gray-600">Plan your study session</p>
        </button>

        <button
          onClick={() => onNavigate('pomodoro')}
          className="bg-white rounded-xl border border-gray-100 p-6 text-left hover:shadow-md transition-all duration-200 group"
        >
          <Clock className="w-8 h-8 text-orange-500 mb-3 group-hover:scale-110 transition-transform duration-200" />
          <h3 className="font-semibold text-gray-900 mb-1">Start Timer</h3>
          <p className="text-sm text-gray-600">Focus with Pomodoro</p>
        </button>
      </div>

      {/* Upcoming Exams */}
      {upcomingExams.length > 0 && (
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Upcoming Exams</h2>
          <div className="space-y-3">
            {upcomingExams.map((subject) => (
              <div key={subject.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-3"
                    style={{ backgroundColor: subject.color }}
                  />
                  <span className="font-medium text-gray-900">{subject.name}</span>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">
                    {getDaysUntilExam(subject.examDate!)} days
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(subject.examDate!).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}