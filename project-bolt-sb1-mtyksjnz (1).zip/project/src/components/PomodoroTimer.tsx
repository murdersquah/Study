import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  Square, 
  Volume2, 
  VolumeX,
  Settings,
  Coffee,
  Brain,
  Maximize
} from 'lucide-react';
import { PomodoroSettings } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';

export default function PomodoroTimer() {
  const [settings, setSettings] = useLocalStorage<PomodoroSettings>('pomodoro-settings', {
    studyDuration: 25,
    shortBreak: 5,
    longBreak: 15,
    ambientSound: 'none',
  });

  const [timeLeft, setTimeLeft] = useState(settings.studyDuration * 60);
  const [isActive, setIsActive] = useState(false);
  const [currentPhase, setCurrentPhase] = useState<'study' | 'shortBreak' | 'longBreak'>('study');
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [ambientVolume, setAmbientVolume] = useState(0.3);

  const audioRef = useRef<HTMLAudioElement>(null);
  const ambientAudioRef = useRef<HTMLAudioElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Ambient sound URLs (using royalty-free sounds)
  const ambientSounds = {
    none: { label: 'None', url: null },
    rain: { 
      label: 'Rain', 
      url: 'https://www.soundjay.com/misc/sounds/rain-01.wav'
    },
    cafe: { 
      label: 'Coffee Shop', 
      url: 'https://www.soundjay.com/misc/sounds/coffee-shop.wav'
    },
    whitenoise: { 
      label: 'White Noise', 
      url: null // Removed problematic base64 data
    },
    forest: { 
      label: 'Forest', 
      url: 'https://www.soundjay.com/nature/sounds/forest-01.wav'
    },
    ocean: { 
      label: 'Ocean Waves', 
      url: 'https://www.soundjay.com/nature/sounds/ocean-01.wav'
    }
  };

  useEffect(() => {
    if (isActive && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(time => time - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      handlePhaseComplete();
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isActive, timeLeft]);

  // Handle ambient sound changes
  useEffect(() => {
    if (ambientAudioRef.current) {
      ambientAudioRef.current.pause();
    }

    if (settings.ambientSound !== 'none' && isActive) {
      const soundData = ambientSounds[settings.ambientSound as keyof typeof ambientSounds];
      if (soundData?.url) {
        if (ambientAudioRef.current) {
          ambientAudioRef.current.src = soundData.url;
          ambientAudioRef.current.volume = ambientVolume;
          ambientAudioRef.current.loop = true;
          ambientAudioRef.current.play().catch(console.error);
        }
      }
    }
  }, [settings.ambientSound, isActive, ambientVolume]);

  const handlePhaseComplete = () => {
    setIsActive(false);
    
    // Stop ambient sound
    if (ambientAudioRef.current) {
      ambientAudioRef.current.pause();
    }
    
    if (currentPhase === 'study') {
      setSessionsCompleted(prev => prev + 1);
      const newPhase = (sessionsCompleted + 1) % 4 === 0 ? 'longBreak' : 'shortBreak';
      setCurrentPhase(newPhase);
      setTimeLeft((newPhase === 'longBreak' ? settings.longBreak : settings.shortBreak) * 60);
    } else {
      setCurrentPhase('study');
      setTimeLeft(settings.studyDuration * 60);
    }

    // Play notification sound
    if (soundEnabled) {
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmweBTWG0fPTgjMGHm7A7+OZUQ0SVa3n77BdGws8ltryxnkpBSl+zPLaizsIFGO57OOdTgwOUarm7blmHgh');
      audio.volume = 0.3;
      audio.play().catch(() => {});
    }
  };

  const toggleTimer = () => {
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    setIsActive(false);
    setCurrentPhase('study');
    setTimeLeft(settings.studyDuration * 60);
    setSessionsCompleted(0);
    
    // Stop ambient sound
    if (ambientAudioRef.current) {
      ambientAudioRef.current.pause();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getPhaseInfo = () => {
    switch (currentPhase) {
      case 'study':
        return { title: 'Focus Time', icon: Brain, color: 'text-blue-600', bgColor: 'bg-blue-50' };
      case 'shortBreak':
        return { title: 'Short Break', icon: Coffee, color: 'text-green-600', bgColor: 'bg-green-50' };
      case 'longBreak':
        return { title: 'Long Break', icon: Coffee, color: 'text-purple-600', bgColor: 'bg-purple-50' };
    }
  };

  const phaseInfo = getPhaseInfo();
  const progress = ((getCurrentPhaseDuration() * 60 - timeLeft) / (getCurrentPhaseDuration() * 60)) * 100;

  function getCurrentPhaseDuration() {
    switch (currentPhase) {
      case 'study': return settings.studyDuration;
      case 'shortBreak': return settings.shortBreak;
      case 'longBreak': return settings.longBreak;
    }
  }

  return (
    <div className={`${isFullscreen ? 'fixed inset-0 z-50 bg-white' : ''}`}>
      {/* Hidden audio element for ambient sounds */}
      <audio ref={ambientAudioRef} preload="none" />
      
      <div className="max-w-2xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <phaseInfo.icon className={`w-6 h-6 mr-2 ${phaseInfo.color}`} />
            <h1 className="text-2xl font-bold text-gray-900">{phaseInfo.title}</h1>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors duration-200"
            >
              <Settings className="w-5 h-5" />
            </button>
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors duration-200"
            >
              <Maximize className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Timer Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Study Duration (minutes)
                </label>
                <input
                  type="number"
                  value={settings.studyDuration}
                  onChange={(e) => setSettings({...settings, studyDuration: parseInt(e.target.value) || 25})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="1"
                  max="60"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Short Break (minutes)
                </label>
                <input
                  type="number"
                  value={settings.shortBreak}
                  onChange={(e) => setSettings({...settings, shortBreak: parseInt(e.target.value) || 5})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="1"
                  max="30"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Long Break (minutes)
                </label>
                <input
                  type="number"
                  value={settings.longBreak}
                  onChange={(e) => setSettings({...settings, longBreak: parseInt(e.target.value) || 15})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="1"
                  max="60"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ambient Sound
                </label>
                <select
                  value={settings.ambientSound}
                  onChange={(e) => setSettings({...settings, ambientSound: e.target.value as any})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {Object.entries(ambientSounds).map(([key, sound]) => (
                    <option key={key} value={key}>{sound.label}</option>
                  ))}
                </select>
              </div>
              
              {settings.ambientSound !== 'none' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Ambient Volume
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={ambientVolume}
                    onChange={(e) => setAmbientVolume(parseFloat(e.target.value))}
                    className="w-full"
                  />
                  <div className="text-xs text-gray-500 mt-1">
                    {Math.round(ambientVolume * 100)}%
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Timer Display */}
        <div className={`${phaseInfo.bgColor} rounded-3xl p-8 text-center`}>
          <div className="relative w-64 h-64 mx-auto mb-8">
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="2"
                fill="transparent"
                className="text-gray-200"
              />
              <circle
                cx="50"
                cy="50"
                r="45"
                stroke="currentColor"
                strokeWidth="2"
                fill="transparent"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                className={phaseInfo.color}
                style={{ transition: 'stroke-dashoffset 1s ease-in-out' }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {formatTime(timeLeft)}
                </div>
                <div className={`text-sm font-medium ${phaseInfo.color}`}>
                  {phaseInfo.title}
                </div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center space-x-4">
            <button
              onClick={toggleTimer}
              className={`w-16 h-16 rounded-full flex items-center justify-center text-white transition-all duration-200 ${
                isActive 
                  ? 'bg-red-500 hover:bg-red-600' 
                  : 'bg-green-500 hover:bg-green-600'
              }`}
            >
              {isActive ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
            </button>
            <button
              onClick={resetTimer}
              className="w-12 h-12 rounded-full bg-gray-500 hover:bg-gray-600 text-white flex items-center justify-center transition-colors duration-200"
            >
              <Square className="w-6 h-6" />
            </button>
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors duration-200 ${
                soundEnabled 
                  ? 'bg-blue-500 hover:bg-blue-600 text-white' 
                  : 'bg-gray-200 hover:bg-gray-300 text-gray-600'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Session Info */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-gray-900">Sessions Completed</h3>
              <p className="text-2xl font-bold text-blue-600">{sessionsCompleted}</p>
            </div>
            <div className="text-right">
              <h4 className="font-medium text-gray-700">Next Phase</h4>
              <p className="text-sm text-gray-500">
                {currentPhase === 'study' 
                  ? (sessionsCompleted + 1) % 4 === 0 ? 'Long Break' : 'Short Break'
                  : 'Focus Time'
                }
              </p>
            </div>
          </div>
          
          {/* Ambient Sound Status */}
          {settings.ambientSound !== 'none' && (
            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Volume2 className="w-4 h-4 text-gray-500 mr-2" />
                  <span className="text-sm text-gray-600">
                    Ambient: {ambientSounds[settings.ambientSound as keyof typeof ambientSounds]?.label}
                  </span>
                </div>
                <div className="text-sm text-gray-500">
                  {Math.round(ambientVolume * 100)}% volume
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}