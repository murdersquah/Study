import React, { useState } from 'react';
import { Calendar, Plus, Clock, Target, Lightbulb } from 'lucide-react';
import { Subject, Topic, DailyPlan } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface StudyPlannerProps {
  subjects: Subject[];
}

export default function StudyPlanner({ subjects }: StudyPlannerProps) {
  const today = new Date().toISOString().split('T')[0];
  const [dailyPlans, setDailyPlans] = useLocalStorage<DailyPlan[]>('studyapp-plans', []);
  const [selectedDate, setSelectedDate] = useState(today);
  const [draggedTopic, setDraggedTopic] = useState<{ subjectId: string; moduleId: string; topic: Topic } | null>(null);

  const currentPlan = dailyPlans.find(plan => plan.date === selectedDate) || {
    date: selectedDate,
    topics: [],
    completed: [],
    pomodoroCount: 0,
  };

  const savePlan = (updatedPlan: DailyPlan) => {
    const updatedPlans = dailyPlans.filter(plan => plan.date !== selectedDate);
    setDailyPlans([...updatedPlans, updatedPlan]);
  };

  const addTopicToPlan = (subjectId: string, moduleId: string, topicId: string) => {
    if (!currentPlan.topics.includes(topicId)) {
      const updatedPlan = {
        ...currentPlan,
        topics: [...currentPlan.topics, topicId],
      };
      savePlan(updatedPlan);
    }
  };

  const removeTopicFromPlan = (topicId: string) => {
    const updatedPlan = {
      ...currentPlan,
      topics: currentPlan.topics.filter(id => id !== topicId),
      completed: currentPlan.completed.filter(id => id !== topicId),
    };
    savePlan(updatedPlan);
  };

  const toggleTopicCompletion = (topicId: string) => {
    const isCompleted = currentPlan.completed.includes(topicId);
    const updatedPlan = {
      ...currentPlan,
      completed: isCompleted 
        ? currentPlan.completed.filter(id => id !== topicId)
        : [...currentPlan.completed, topicId],
    };
    savePlan(updatedPlan);
  };

  const getTopicDetails = (topicId: string) => {
    for (const subject of subjects) {
      for (const module of subject.modules) {
        const topic = module.topics.find(t => t.id === topicId);
        if (topic) {
          return { subject, module, topic };
        }
      }
    }
    return null;
  };

  const getSmartSuggestions = () => {
    const allTopics = subjects.flatMap(subject =>
      subject.modules.flatMap(module =>
        module.topics
          .filter(topic => !topic.completed)
          .map(topic => ({ subject, module, topic }))
      )
    );

    // Prioritize topics from subjects with upcoming exams
    const urgent = allTopics.filter(({ subject }) => {
      if (!subject.examDate) return false;
      const daysUntil = Math.ceil((new Date(subject.examDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
      return daysUntil <= 14;
    });

    return urgent.length > 0 ? urgent.slice(0, 5) : allTopics.slice(0, 5);
  };

  const handleDragStart = (subjectId: string, moduleId: string, topic: Topic) => {
    setDraggedTopic({ subjectId, moduleId, topic });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (draggedTopic) {
      addTopicToPlan(draggedTopic.subjectId, draggedTopic.moduleId, draggedTopic.topic.id);
      setDraggedTopic(null);
    }
  };

  const completionPercentage = currentPlan.topics.length > 0 
    ? (currentPlan.completed.length / currentPlan.topics.length) * 100 
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Study Planner</h1>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Today's Plan */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">
                {selectedDate === today ? "Today's Plan" : `Plan for ${new Date(selectedDate).toLocaleDateString()}`}
              </h2>
              <div className="text-sm text-gray-500">
                {currentPlan.completed.length} / {currentPlan.topics.length} completed
              </div>
            </div>

            {completionPercentage > 0 && (
              <div className="mb-4">
                <div className="bg-gray-100 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${completionPercentage}%` }}
                  />
                </div>
                <p className="text-sm text-gray-600 mt-1">{completionPercentage.toFixed(0)}% complete</p>
              </div>
            )}

            <div 
              className="min-h-[300px] border-2 border-dashed border-gray-200 rounded-lg p-4"
              onDragOver={handleDragOver}
              onDrop={handleDrop}
            >
              {currentPlan.topics.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500">
                  <Target className="w-12 h-12 mb-3 text-gray-300" />
                  <p className="text-lg font-medium mb-2">No topics planned</p>
                  <p className="text-sm">Drag topics from the sidebar or use smart suggestions</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {currentPlan.topics.map(topicId => {
                    const details = getTopicDetails(topicId);
                    if (!details) return null;

                    const { subject, module, topic } = details;
                    const isCompleted = currentPlan.completed.includes(topicId);

                    return (
                      <div 
                        key={topicId}
                        className={`flex items-center p-3 rounded-lg border transition-all duration-200 ${
                          isCompleted 
                            ? 'bg-green-50 border-green-200' 
                            : 'bg-white border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isCompleted}
                          onChange={() => toggleTopicCompletion(topicId)}
                          className="mr-3 h-4 w-4 text-blue-600 rounded focus:ring-blue-500"
                        />
                        <div className="flex-1">
                          <div className="flex items-center mb-1">
                            <div 
                              className="w-2 h-2 rounded-full mr-2"
                              style={{ backgroundColor: subject.color }}
                            />
                            <span className="text-xs text-gray-500">{subject.name} • {module.name}</span>
                          </div>
                          <p className={`font-medium ${isCompleted ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                            {topic.name}
                          </p>
                        </div>
                        <button
                          onClick={() => removeTopicFromPlan(topicId)}
                          className="text-red-500 hover:text-red-700 text-sm ml-2"
                        >
                          Remove
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Smart Suggestions */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <div className="flex items-center mb-4">
              <Lightbulb className="w-5 h-5 text-yellow-500 mr-2" />
              <h3 className="font-semibold text-gray-900">Smart Suggestions</h3>
            </div>
            <div className="space-y-2">
              {getSmartSuggestions().map(({ subject, module, topic }) => (
                <div
                  key={topic.id}
                  draggable
                  onDragStart={() => handleDragStart(subject.id, module.id, topic)}
                  className="p-3 border border-gray-200 rounded-lg cursor-move hover:bg-blue-50 hover:border-blue-300 transition-all duration-200"
                >
                  <div className="flex items-center mb-1">
                    <div 
                      className="w-2 h-2 rounded-full mr-2"
                      style={{ backgroundColor: subject.color }}
                    />
                    <span className="text-xs text-gray-500">{subject.name}</span>
                  </div>
                  <p className="text-sm font-medium text-gray-900">{topic.name}</p>
                  <button
                    onClick={() => addTopicToPlan(subject.id, module.id, topic.id)}
                    className="text-xs text-blue-600 hover:text-blue-800 mt-1"
                  >
                    Add to plan
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* All Topics */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">All Topics</h3>
            <div className="max-h-96 overflow-y-auto space-y-4">
              {subjects.map(subject => (
                <div key={subject.id}>
                  <div className="flex items-center mb-2">
                    <div 
                      className="w-3 h-3 rounded-full mr-2"
                      style={{ backgroundColor: subject.color }}
                    />
                    <h4 className="font-medium text-gray-900">{subject.name}</h4>
                  </div>
                  {subject.modules.map(module => (
                    <div key={module.id} className="ml-5 mb-3">
                      <p className="text-sm text-gray-600 mb-2">{module.name}</p>
                      <div className="space-y-1">
                        {module.topics
                          .filter(topic => !topic.completed)
                          .map(topic => (
                            <div
                              key={topic.id}
                              draggable
                              onDragStart={() => handleDragStart(subject.id, module.id, topic)}
                              className="p-2 text-sm text-gray-700 border border-gray-100 rounded cursor-move hover:bg-blue-50 hover:border-blue-200 transition-all duration-200"
                            >
                              {topic.name}
                            </div>
                          ))}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}