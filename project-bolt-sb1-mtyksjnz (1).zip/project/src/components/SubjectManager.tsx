import React, { useState } from 'react';
import { 
  Plus, 
  BookOpen, 
  Upload,
  ChevronDown,
  ChevronRight,
  CheckCircle,
  Circle,
  FileText,
  Sparkles,
  Target,
  Award,
  Zap,
  Loader,
  File,
  Brain,
  List,
  CheckSquare,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { Subject, Module, Topic } from '../types';
import { createConfetti } from '../utils/confetti';
import { getRandomQuote } from '../utils/motivationalQuotes';
import { 
  parseSyllabusText, 
  extractTextFromPDF
} from '../utils/syllabusParser';

interface SubjectManagerProps {
  subjects: Subject[];
  onUpdateSubjects: (subjects: Subject[]) => void;
}

export default function SubjectManager({ subjects, onUpdateSubjects }: SubjectManagerProps) {
  const [showAddSubject, setShowAddSubject] = useState(false);
  const [newSubjectName, setNewSubjectName] = useState('');
  const [newSubjectColor, setNewSubjectColor] = useState('#3B82F6');
  const [expandedSubjects, setExpandedSubjects] = useState<Set<string>>(new Set());
  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set());
  const [showQuote, setShowQuote] = useState(false);
  const [currentQuote, setCurrentQuote] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadingSubject, setUploadingSubject] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', 
    '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6366F1',
    '#14B8A6', '#F43F5E', '#8B5A2B', '#7C3AED', '#DC2626'
  ];

  const addSubject = () => {
    if (!newSubjectName.trim()) return;

    const newSubject: Subject = {
      id: Math.random().toString(36).substr(2, 9),
      name: newSubjectName,
      color: newSubjectColor,
      modules: [],
      progress: 0,
    };

    onUpdateSubjects([...subjects, newSubject]);
    setNewSubjectName('');
    setShowAddSubject(false);
  };

  const deleteSubject = (subjectId: string) => {
    const updatedSubjects = subjects.filter(subject => subject.id !== subjectId);
    onUpdateSubjects(updatedSubjects);
    setDeleteConfirm(null);
  };

  const toggleSubject = (subjectId: string) => {
    const newExpanded = new Set(expandedSubjects);
    if (newExpanded.has(subjectId)) {
      newExpanded.delete(subjectId);
    } else {
      newExpanded.add(subjectId);
    }
    setExpandedSubjects(newExpanded);
  };

  const toggleModule = (moduleId: string) => {
    const newExpanded = new Set(expandedModules);
    if (newExpanded.has(moduleId)) {
      newExpanded.delete(moduleId);
    } else {
      newExpanded.add(moduleId);
    }
    setExpandedModules(newExpanded);
  };

  const toggleTopic = (subjectId: string, moduleId: string, topicId: string) => {
    const updatedSubjects = subjects.map(subject => {
      if (subject.id === subjectId) {
        const updatedModules = subject.modules.map(module => {
          if (module.id === moduleId) {
            const updatedTopics = module.topics.map(topic => {
              if (topic.id === topicId) {
                const newCompleted = !topic.completed;
                if (newCompleted) {
                  createConfetti();
                  setCurrentQuote(getRandomQuote());
                  setShowQuote(true);
                  setTimeout(() => setShowQuote(false), 3000);
                }
                return { ...topic, completed: newCompleted, completedAt: newCompleted ? new Date() : undefined };
              }
              return topic;
            });
            
            const moduleProgress = updatedTopics.length > 0 ? (updatedTopics.filter(t => t.completed).length / updatedTopics.length) * 100 : 0;
            return { ...module, topics: updatedTopics, progress: moduleProgress };
          }
          return module;
        });
        
        const subjectProgress = updatedModules.length > 0 
          ? updatedModules.reduce((acc, mod) => acc + mod.progress, 0) / updatedModules.length
          : 0;
        
        return { ...subject, modules: updatedModules, progress: subjectProgress };
      }
      return subject;
    });

    onUpdateSubjects(updatedSubjects);
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>, subjectId: string) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Only accept PDF files
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      alert('Please upload a PDF file only.');
      event.target.value = '';
      return;
    }

    setIsUploading(true);
    setUploadingSubject(subjectId);
    
    try {
      console.log(`📄 Processing PDF file: ${file.name}`);
      console.log(`📁 File size: ${(file.size / 1024).toFixed(1)} KB`);

      // Extract text from PDF
      console.log('📄 Extracting text from PDF...');
      const text = await extractTextFromPDF(file);

      console.log(`✅ Extracted text length: ${text.length} characters`);
      console.log('🔍 Preview:', text.substring(0, 300) + '...');

      if (!text || text.trim().length < 10) {
        throw new Error('PDF appears to be empty or contains no readable text');
      }

      // Parse the text for modules and topics using AI-like analysis
      console.log('🧠 Analyzing PDF content structure with enhanced dash parsing...');
      const parsed = parseSyllabusText(text);
      
      console.log('📋 Analysis complete:', {
        subject: parsed.subjectName,
        modules: parsed.modules.length,
        topics: parsed.modules.reduce((acc, mod) => acc + mod.topics.length, 0)
      });

      if (parsed.modules.length === 0) {
        throw new Error('No modules found in the PDF. Please check the format or try a different file.');
      }

      // Create module structure with proper IDs
      const modules: Module[] = parsed.modules.map((mod, index) => ({
        id: Math.random().toString(36).substr(2, 9),
        name: mod.name || `Module ${index + 1}`,
        topics: mod.topics.map((topicName, topicIndex) => ({
          id: Math.random().toString(36).substr(2, 9),
          name: topicName,
          completed: false,
        })),
        progress: 0,
      }));

      // Update the subject
      const updatedSubjects = subjects.map(subject => {
        if (subject.id === subjectId) {
          return { 
            ...subject, 
            modules,
            name: parsed.subjectName !== 'Untitled Subject' ? parsed.subjectName : subject.name
          };
        }
        return subject;
      });

      onUpdateSubjects(updatedSubjects);
      
      // Auto-expand the subject and first module after successful upload
      setExpandedSubjects(prev => new Set([...prev, subjectId]));
      if (modules.length > 0) {
        setExpandedModules(prev => new Set([...prev, modules[0].id]));
      }
      
      console.log('🎉 Successfully uploaded and parsed PDF syllabus');
      
    } catch (error) {
      console.error('❌ Error processing PDF:', error);
      alert(`Error processing PDF: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsUploading(false);
      setUploadingSubject(null);
      // Reset file input
      event.target.value = '';
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress < 25) return 'from-red-400 to-red-500';
    if (progress < 50) return 'from-orange-400 to-orange-500';
    if (progress < 75) return 'from-yellow-400 to-yellow-500';
    return 'from-green-400 to-green-500';
  };

  const totalTopics = subjects.reduce((acc, subject) => 
    acc + subject.modules.reduce((modAcc, module) => modAcc + module.topics.length, 0), 0
  );
  
  const completedTopics = subjects.reduce((acc, subject) => 
    acc + subject.modules.reduce((modAcc, module) => 
      modAcc + module.topics.filter(topic => topic.completed).length, 0
    ), 0
  );

  const overallProgress = totalTopics > 0 ? (completedTopics / totalTopics) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Motivational Quote Popup */}
      {showQuote && (
        <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
          <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl shadow-2xl border-2 border-white p-6 mx-4 max-w-md animate-fade-in">
            <div className="flex items-center mb-2">
              <Sparkles className="w-6 h-6 mr-2" />
              <span className="font-semibold">Awesome!</span>
            </div>
            <p className="text-lg font-medium text-center">{currentQuote}</p>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 w-full max-w-md mx-4 shadow-2xl">
            <div className="flex items-center mb-4">
              <AlertTriangle className="w-8 h-8 text-red-500 mr-3" />
              <h2 className="text-2xl font-bold text-gray-900">Delete Subject</h2>
            </div>
            
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this subject? This action cannot be undone and will remove all modules and topics.
            </p>

            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="px-6 py-3 text-gray-600 hover:text-gray-800 transition-colors duration-200 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => deleteSubject(deleteConfirm)}
                className="px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all duration-200 font-medium"
              >
                Delete Subject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mr-4">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              My Subjects
            </h1>
            <p className="text-gray-600">Upload PDF syllabus to extract modules and topics automatically</p>
          </div>
        </div>
        <button
          onClick={() => setShowAddSubject(true)}
          className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center shadow-lg hover:shadow-xl transform hover:scale-105"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Subject
        </button>
      </div>

      {/* Overall Progress */}
      {subjects.length > 0 && (
        <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold">Overall Progress</h2>
              <p className="text-indigo-100">
                {completedTopics} of {totalTopics} topics completed
              </p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{overallProgress.toFixed(1)}%</div>
              <div className="text-indigo-100">Complete</div>
            </div>
          </div>
          <div className="bg-white/20 rounded-full h-3">
            <div 
              className="bg-white rounded-full h-3 transition-all duration-500 ease-out"
              style={{ width: `${overallProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Add Subject Modal */}
      {showAddSubject && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-3xl p-8 w-full max-w-md mx-4 shadow-2xl">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Add New Subject</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Subject Name
                </label>
                <input
                  type="text"
                  value={newSubjectName}
                  onChange={(e) => setNewSubjectName(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                  placeholder="e.g., Discrete Mathematics and Graph Theory"
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Choose Color
                </label>
                <div className="grid grid-cols-5 gap-3">
                  {colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setNewSubjectColor(color)}
                      className={`w-12 h-12 rounded-xl border-4 transition-all duration-200 hover:scale-110 ${
                        newSubjectColor === color ? 'border-gray-900 shadow-lg' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4 mt-8">
              <button
                onClick={() => setShowAddSubject(false)}
                className="px-6 py-3 text-gray-600 hover:text-gray-800 transition-colors duration-200 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={addSubject}
                className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 font-medium"
              >
                Add Subject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subjects List */}
      <div className="space-y-6">
        {subjects.map(subject => (
          <div key={subject.id} className="bg-white rounded-3xl border-2 border-gray-100 overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <button
                    onClick={() => toggleSubject(subject.id)}
                    className="mr-4 p-2 hover:bg-gray-100 rounded-xl transition-colors duration-200"
                  >
                    {expandedSubjects.has(subject.id) ? (
                      <ChevronDown className="w-6 h-6 text-gray-600" />
                    ) : (
                      <ChevronRight className="w-6 h-6 text-gray-600" />
                    )}
                  </button>
                  <div 
                    className="w-6 h-6 rounded-full mr-4 shadow-lg"
                    style={{ backgroundColor: subject.color }}
                  />
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{subject.name}</h2>
                    <div className="flex items-center text-gray-600">
                      <List className="w-4 h-4 mr-1" />
                      <span className="mr-4">
                        {subject.modules.length} modules
                      </span>
                      <CheckSquare className="w-4 h-4 mr-1" />
                      <span>
                        {subject.modules.reduce((acc, mod) => acc + mod.topics.length, 0)} topics
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="text-2xl font-bold text-gray-900">
                      {subject.progress.toFixed(0)}%
                    </div>
                    <div className="text-sm text-gray-500">Complete</div>
                  </div>
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={(e) => handleFileUpload(e, subject.id)}
                      className="hidden"
                      disabled={isUploading}
                    />
                    <div className={`flex items-center px-4 py-2 rounded-xl transition-all duration-200 ${
                      uploadingSubject === subject.id
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-red-500 to-orange-500 text-white hover:from-red-600 hover:to-orange-600 shadow-lg hover:shadow-xl transform hover:scale-105'
                    }`}>
                      {uploadingSubject === subject.id ? (
                        <Loader className="w-5 h-5 mr-2 animate-spin" />
                      ) : (
                        <File className="w-5 h-5 mr-2" />
                      )}
                      {uploadingSubject === subject.id ? 'Analyzing...' : 'Upload PDF'}
                    </div>
                  </label>
                  <button
                    onClick={() => setDeleteConfirm(subject.id)}
                    className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-xl transition-all duration-200"
                    title="Delete Subject"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>

              <div className="mb-6">
                <div className="bg-gray-100 rounded-full h-3">
                  <div 
                    className={`h-3 rounded-full transition-all duration-500 ease-out bg-gradient-to-r ${getProgressColor(subject.progress)}`}
                    style={{ width: `${subject.progress}%` }}
                  />
                </div>
              </div>

              {expandedSubjects.has(subject.id) && (
                <div className="space-y-4">
                  {subject.modules.length === 0 ? (
                    <div className="text-center py-12 bg-gradient-to-br from-gray-50 to-red-50 rounded-2xl border-2 border-dashed border-red-200">
                      <div className="w-16 h-16 bg-gradient-to-r from-red-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                        <File className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload PDF Syllabus</h3>
                      <p className="text-gray-600 mb-4">Upload a PDF syllabus to automatically extract modules and topics</p>
                      
                      {/* Sample Format Display */}
                      <div className="bg-white rounded-xl p-4 mx-4 mb-4 border border-gray-200">
                        <h4 className="font-semibold text-gray-800 mb-2">Expected PDF Format:</h4>
                        <div className="text-left text-sm text-gray-700 space-y-1">
                          <div className="font-medium text-blue-600">Module:1 Mathematical Logic</div>
                          <div className="text-gray-600 ml-2">Statements and Notation - Connectives - Tautologies - Equivalence</div>
                          <div className="font-medium text-blue-600 mt-2">Module:2 Algebraic Structures</div>
                          <div className="text-gray-600 ml-2">Semigroups and Monoids - Groups - Subgroups</div>
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-500">
                        <strong>Only PDF files accepted</strong> - Topics separated by dashes (-)
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <h3 className="text-lg font-semibold text-gray-800 mb-3">Modules:</h3>
                      {subject.modules.map(module => (
                        <div key={module.id} className="border-2 border-gray-100 rounded-2xl p-5 bg-gradient-to-r from-white to-gray-50">
                          <div className="flex items-center justify-between mb-4">
                            <button
                              onClick={() => toggleModule(module.id)}
                              className="flex items-center flex-1 text-left hover:bg-white rounded-xl p-2 transition-colors duration-200"
                            >
                              {expandedModules.has(module.id) ? (
                                <ChevronDown className="w-5 h-5 mr-3 text-gray-600" />
                              ) : (
                                <ChevronRight className="w-5 h-5 mr-3 text-gray-600" />
                              )}
                              <div className="flex items-center">
                                <div 
                                  className="w-3 h-3 rounded-full mr-3"
                                  style={{ backgroundColor: subject.color }}
                                />
                                <h4 className="font-bold text-gray-900 text-lg">{module.name}</h4>
                              </div>
                            </button>
                            <div className="flex items-center space-x-3">
                              <span className="text-sm font-medium text-gray-600 bg-white px-3 py-1 rounded-full border">
                                {module.topics.filter(t => t.completed).length}/{module.topics.length} topics
                              </span>
                              <div className="text-right">
                                <div className="text-lg font-bold" style={{ color: subject.color }}>
                                  {module.progress.toFixed(0)}%
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="bg-gray-200 rounded-full h-2 mb-4">
                            <div 
                              className="h-2 rounded-full transition-all duration-300"
                              style={{ 
                                width: `${module.progress}%`,
                                backgroundColor: subject.color 
                              }}
                            />
                          </div>

                          {expandedModules.has(module.id) && (
                            <div className="space-y-3">
                              <div className="text-sm text-gray-600 mb-3 flex items-center">
                                <CheckSquare className="w-4 h-4 mr-2" />
                                Check off topics as you complete them:
                              </div>
                              {module.topics.map(topic => (
                                <div 
                                  key={topic.id}
                                  className={`flex items-center p-4 rounded-xl transition-all duration-200 cursor-pointer ${
                                    topic.completed 
                                      ? 'bg-green-50 border-2 border-green-200 shadow-sm' 
                                      : 'bg-white border-2 border-gray-100 hover:border-gray-200 hover:shadow-md'
                                  }`}
                                  onClick={() => toggleTopic(subject.id, module.id, topic.id)}
                                >
                                  <button
                                    className="mr-4 transition-transform duration-200 hover:scale-110"
                                  >
                                    {topic.completed ? (
                                      <CheckCircle className="w-6 h-6 text-green-500" />
                                    ) : (
                                      <Circle className="w-6 h-6 text-gray-300 hover:text-gray-400" />
                                    )}
                                  </button>
                                  <span className={`flex-1 font-medium transition-all duration-200 ${
                                    topic.completed 
                                      ? 'line-through text-gray-500' 
                                      : 'text-gray-900'
                                  }`}>
                                    {topic.name}
                                  </span>
                                  {topic.completed && (
                                    <div className="flex items-center text-green-600">
                                      <Zap className="w-4 h-4 mr-1" />
                                      <span className="text-sm font-medium">Done!</span>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {subjects.length === 0 && (
        <div className="text-center py-16 bg-gradient-to-br from-blue-50 via-white to-red-50 rounded-3xl border-2 border-gray-100">
          <div className="w-20 h-20 bg-gradient-to-r from-red-500 to-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <File className="w-10 h-10 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-3">No subjects yet</h3>
          <p className="text-gray-600 mb-6 max-w-md mx-auto">
            Add your first subject and upload a PDF syllabus for automatic module and topic extraction
          </p>
          
          {/* Sample Format Display */}
          <div className="bg-white rounded-xl p-4 max-w-lg mx-auto mb-6 border border-gray-200">
            <h4 className="font-semibold text-gray-800 mb-2">Expected PDF Format:</h4>
            <div className="text-left text-sm text-gray-700 space-y-1">
              <div className="font-medium text-blue-600">Module:1 Mathematical Logic</div>
              <div className="text-gray-600 ml-2">Statements and Notation - Connectives - Tautologies</div>
              <div className="font-medium text-blue-600 mt-2">Module:2 Algebraic Structures</div>
              <div className="text-gray-600 ml-2">Semigroups and Monoids - Groups - Subgroups</div>
            </div>
          </div>
          
          <button
            onClick={() => setShowAddSubject(true)}
            className="bg-gradient-to-r from-red-500 to-orange-600 text-white px-8 py-4 rounded-xl hover:from-red-600 hover:to-orange-700 transition-all duration-200 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            Add Your First Subject
          </button>
        </div>
      )}
    </div>
  );
}