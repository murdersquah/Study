import React, { useState } from 'react';
import { useLocalStorage } from './hooks/useLocalStorage';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import SubjectManager from './components/SubjectManager';
import StudyPlanner from './components/StudyPlanner';
import PomodoroTimer from './components/PomodoroTimer';
import Stats from './components/Stats';
import { Subject, UserStats } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [subjects, setSubjects] = useLocalStorage<Subject[]>('studyapp-subjects', []);
  const [stats] = useLocalStorage<UserStats>('studyapp-stats', {
    totalTopicsCompleted: 0,
    weeklyPomodoros: 12,
    currentStreak: 3,
    longestStreak: 7,
    badges: ['first-topic', 'streak-3'],
  });

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard subjects={subjects} stats={stats} onNavigate={setCurrentPage} />;
      case 'subjects':
        return <SubjectManager subjects={subjects} onUpdateSubjects={setSubjects} />;
      case 'planner':
        return <StudyPlanner subjects={subjects} />;
      case 'pomodoro':
        return <PomodoroTimer />;
      case 'stats':
        return <Stats subjects={subjects} stats={stats} />;
      default:
        return <Dashboard subjects={subjects} stats={stats} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-1 overflow-auto">
        <div className="max-w-7xl mx-auto p-6">
          {renderCurrentPage()}
        </div>
      </main>
    </div>
  );
}

export default App;