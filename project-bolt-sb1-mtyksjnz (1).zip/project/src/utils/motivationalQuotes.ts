export const motivationalQuotes = [
  "You're getting there.",
  "Consistent beats intense.",
  "Progress, not perfection.",
  "One topic at a time.",
  "You've got this.",
  "Small steps, big dreams.",
  "Learning is a journey.",
  "Every expert was once a beginner.",
  "Focus on the process.",
  "Your future self will thank you.",
  "Knowledge is power.",
  "Success is built daily.",
  "Keep going.",
  "You're stronger than you think.",
  "Excellence is a habit."
];

export const getRandomQuote = (): string => {
  return motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
};