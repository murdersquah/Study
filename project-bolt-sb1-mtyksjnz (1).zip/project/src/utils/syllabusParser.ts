import * as pdfjsLib from 'pdfjs-dist';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

export interface ParsedSyllabus {
  subjectName: string;
  modules: {
    name: string;
    topics: string[];
  }[];
}

// Enhanced AI-like analysis for better module and topic detection with dash separation
export const parseSyllabusText = (text: string): ParsedSyllabus => {
  const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  
  let subjectName = 'Untitled Subject';
  const modules: { name: string; topics: string[] }[] = [];
  let currentModule: { name: string; topics: string[] } | null = null;

  console.log('Starting enhanced syllabus analysis...');
  console.log('Total lines to process:', lines.length);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const nextLine = lines[i + 1] || '';

    // Skip very short lines that are likely noise
    if (line.length < 3) continue;

    console.log('Processing line:', line);

    // Enhanced subject name detection
    const subjectPatterns = [
      /^(subject|course|title|name):\s*(.+)/i,
      /^(.+)\s+(syllabus|curriculum|course\s+outline)/i,
      /^course\s+code:\s*\w+\s*-?\s*(.+)/i,
    ];

    for (const pattern of subjectPatterns) {
      const match = line.match(pattern);
      if (match) {
        subjectName = match[2] || match[1];
        subjectName = subjectName.replace(/syllabus|curriculum|course\s+outline/i, '').trim();
        console.log('Found subject name:', subjectName);
        continue;
      }
    }

    // Enhanced module detection with specific focus on "Module:1" format
    const modulePatterns = [
      // Specific pattern for "Module:1 Name" or "Module 1: Name"
      /^module\s*:?\s*(\d+)\s*:?\s*(.+)/i,
      /^(\d+)\s*\.?\s*module\s*:?\s*(.+)/i,
      
      // Standard module patterns
      /^(module|chapter|unit|week|section|part|lesson)\s+(\d+|[ivx]+)[\s:.-]*(.+)/i,
      /^(\d+)[\s.-]+(module|chapter|unit|week|section|part)[\s:.-]*(.+)/i,
      
      // Numbered sections
      /^(\d+)\.?\s+([A-Z][^.!?]*[^.!?\s])$/,
      
      // Roman numerals
      /^([ivx]+)[\s.-]+(.+)/i,
      
      // ALL CAPS headers (likely module titles)
      /^[A-Z][A-Z\s&-]{5,}[A-Z]$/,
      
      // Headers with colons
      /^([A-Z][^:]{5,}):\s*$/,
    ];

    let isModuleHeader = false;
    let moduleName = '';
    let moduleNumber = '';

    for (const pattern of modulePatterns) {
      const match = line.match(pattern);
      if (match) {
        isModuleHeader = true;
        
        if (pattern.source.includes('module\\s*:?\\s*(\\d+)')) {
          // Handle "Module:1 Mathematical Logic" format
          moduleNumber = match[1];
          moduleName = match[2].trim();
          moduleName = `Module ${moduleNumber}: ${moduleName}`;
        } else if (pattern.source.includes('module|chapter|unit')) {
          // Extract module number and name
          moduleNumber = match[2] || match[1];
          moduleName = match[3] || match[2] || '';
          
          // Clean up the module name
          if (moduleName) {
            moduleName = `Module ${moduleNumber}: ${moduleName.trim()}`;
          } else {
            moduleName = `Module ${moduleNumber}`;
          }
        } else if (match[2]) {
          // For numbered sections
          moduleNumber = match[1];
          moduleName = `Module ${moduleNumber}: ${match[2].trim()}`;
        } else {
          // For other patterns
          moduleName = line.trim();
        }
        
        console.log('Found module:', moduleName);
        break;
      }
    }

    // If we found a module header
    if (isModuleHeader) {
      // Save previous module if it has topics
      if (currentModule && currentModule.topics.length > 0) {
        modules.push(currentModule);
        console.log('Saved module with', currentModule.topics.length, 'topics');
      }
      
      currentModule = {
        name: moduleName || line,
        topics: []
      };
      continue;
    }

    // Enhanced topic detection with dash separation
    if (currentModule) {
      // Check if this line contains dash-separated topics
      const hasDashes = line.includes(' - ') || line.includes(' – ') || line.includes(' — ');
      
      if (hasDashes) {
        console.log('Found dash-separated topics in line:', line);
        
        // Split by various dash types and clean up
        const dashTopics = line
          .split(/\s*[-–—]\s*/)
          .map(topic => topic.trim())
          .filter(topic => topic.length > 2)
          .map(topic => {
            // Remove trailing punctuation and clean up
            return topic.replace(/[.,:;]+$/, '').trim();
          });
        
        console.log('Extracted dash topics:', dashTopics);
        
        // Add all topics to current module
        dashTopics.forEach(topic => {
          if (topic && !currentModule!.topics.includes(topic)) {
            currentModule!.topics.push(topic);
            console.log('Added dash topic:', topic);
          }
        });
        continue;
      }
      
      // Standard topic detection patterns
      const topicPatterns = [
        // Standard bullet points
        /^[-•*◦▪▫○→]\s*(.+)/,
        
        // Numbered lists
        /^\d+[\.)]\s*(.+)/,
        
        // Lettered lists
        /^[a-z][\.)]\s*(.+)/i,
        
        // Indented content
        /^\s{2,}(.+)/,
        
        // Dash variations
        /^[–—]\s*(.+)/,
        
        // Parenthetical numbers
        /^\(\d+\)\s*(.+)/,
        
        // Bracketed numbers
        /^\[\d+\]\s*(.+)/,
      ];

      let topicText = '';
      let isTopic = false;

      for (const pattern of topicPatterns) {
        const match = line.match(pattern);
        if (match) {
          topicText = match[1].trim();
          isTopic = true;
          break;
        }
      }

      // Additional topic detection heuristics
      if (!isTopic) {
        // If we're in a module and the line looks like content
        const looksLikeContent = line.length > 10 && 
                                line.length < 200 && 
                                !line.includes(':') &&
                                line !== line.toUpperCase() &&
                                !line.match(/^(module|chapter|unit|week|section|part)/i);
        
        if (looksLikeContent) {
          topicText = line;
          isTopic = true;
        }
      }

      // Add topic to current module
      if (isTopic && topicText.length > 2) {
        // Clean up topic text
        topicText = topicText.replace(/[.,:;]+$/, '').trim();
        
        // Avoid duplicate topics
        if (!currentModule.topics.includes(topicText)) {
          currentModule.topics.push(topicText);
          console.log('Added topic:', topicText);
        }
      }
    }
  }

  // Add the last module if it has topics
  if (currentModule && currentModule.topics.length > 0) {
    modules.push(currentModule);
    console.log('Saved final module with', currentModule.topics.length, 'topics');
  }

  // If no modules were found, try to create a basic structure
  if (modules.length === 0 && lines.length > 0) {
    console.log('No clear modules found, creating basic structure...');
    
    // Look for any content that might be topics
    const potentialTopics = [];
    
    for (const line of lines) {
      if (line.length > 5 && line.length < 200) {
        // Check for dash-separated content
        if (line.includes(' - ') || line.includes(' – ') || line.includes(' — ')) {
          const dashTopics = line
            .split(/\s*[-–—]\s*/)
            .map(topic => topic.trim())
            .filter(topic => topic.length > 2);
          
          potentialTopics.push(...dashTopics);
        } else if (!line.match(/^(page|\d+|copyright|©)/i)) {
          potentialTopics.push(line);
        }
      }
    }

    if (potentialTopics.length > 0) {
      modules.push({
        name: 'Course Content',
        topics: potentialTopics.slice(0, 20)
      });
    }
  }

  console.log('Final parsing result:', {
    subjectName,
    moduleCount: modules.length,
    totalTopics: modules.reduce((acc, mod) => acc + mod.topics.length, 0)
  });

  return { subjectName, modules };
};

// CSV specific parser with better structure detection
export const parseCSV = (csvText: string): ParsedSyllabus => {
  const lines = csvText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  const modules: { name: string; topics: string[] }[] = [];
  let subjectName = 'CSV Subject';
  let currentModule: { name: string; topics: string[] } | null = null;

  console.log('Parsing CSV with', lines.length, 'lines');

  for (const line of lines) {
    // Handle both comma and semicolon separators
    const columns = line.split(/[,;]/).map(col => col.trim().replace(/^["']|["']$/g, ''));
    
    if (columns.length >= 2) {
      const [moduleCol, topicCol] = columns;
      
      // Skip header row
      if (moduleCol.toLowerCase().includes('module') && topicCol.toLowerCase().includes('topic')) {
        continue;
      }
      
      // Detect subject name from first column if it looks like a title
      if (moduleCol.length > 10 && !topicCol && moduleCol.includes(' ')) {
        subjectName = moduleCol;
        continue;
      }
      
      if (moduleCol && moduleCol !== currentModule?.name) {
        if (currentModule && currentModule.topics.length > 0) {
          modules.push(currentModule);
        }
        currentModule = {
          name: moduleCol.includes('Module') ? moduleCol : `Module: ${moduleCol}`,
          topics: []
        };
      }
      
      if (topicCol && currentModule && topicCol.length > 2) {
        // Handle dash-separated topics in CSV
        if (topicCol.includes(' - ') || topicCol.includes(' – ') || topicCol.includes(' — ')) {
          const dashTopics = topicCol
            .split(/\s*[-–—]\s*/)
            .map(topic => topic.trim())
            .filter(topic => topic.length > 2);
          
          currentModule.topics.push(...dashTopics);
        } else {
          currentModule.topics.push(topicCol);
        }
      }
    }
  }

  if (currentModule && currentModule.topics.length > 0) {
    modules.push(currentModule);
  }

  return { subjectName, modules };
};

// PDF text extraction with better formatting preservation
export const extractTextFromPDF = async (file: File): Promise<string> => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';

    console.log('Extracting text from PDF with', pdf.numPages, 'pages');

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      
      // Sort text items by position to maintain reading order
      const sortedItems = textContent.items.sort((a: any, b: any) => {
        if (Math.abs(a.transform[5] - b.transform[5]) > 5) {
          return b.transform[5] - a.transform[5]; // Sort by Y position (top to bottom)
        }
        return a.transform[4] - b.transform[4]; // Sort by X position (left to right)
      });
      
      let pageText = '';
      let lastY = null;
      
      for (const item of sortedItems) {
        const text = (item as any).str || '';
        const y = (item as any).transform[5];
        
        // Add line break if we moved to a new line
        if (lastY !== null && Math.abs(y - lastY) > 5) {
          pageText += '\n';
        }
        
        pageText += text + ' ';
        lastY = y;
      }
      
      fullText += pageText.trim() + '\n\n';
    }

    return fullText.trim();
  } catch (error) {
    console.error('PDF parsing error:', error);
    throw new Error('Failed to parse PDF file. Please ensure it contains readable text.');
  }
};

// DOCX text extraction
export const extractTextFromDOCX = async (file: File): Promise<string> => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    
    // Basic DOCX text extraction
    const uint8Array = new Uint8Array(arrayBuffer);
    const text = new TextDecoder('utf-8', { ignoreBOM: true }).decode(uint8Array);
    
    // Extract text from w:t elements (Word text elements)
    const textMatches = text.match(/<w:t[^>]*>([^<]*)<\/w:t>/g);
    
    if (textMatches) {
      const cleanText = textMatches
        .map(match => match.replace(/<[^>]*>/g, ''))
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim();
      
      if (cleanText.length > 20) {
        return cleanText;
      }
    }
    
    // Fallback: basic text extraction
    let cleanText = text
      .replace(/<[^>]*>/g, ' ')
      .replace(/[^\x20-\x7E\n\r]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (cleanText.length < 20) {
      throw new Error('Could not extract readable text from DOCX file');
    }

    return cleanText;
  } catch (error) {
    console.error('DOCX parsing error:', error);
    throw new Error('Failed to parse DOCX file. Please try converting to PDF or TXT format.');
  }
};

// TXT file reader
export const extractTextFromTXT = async (file: File): Promise<string> => {
  try {
    return await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        if (text && text.trim().length > 0) {
          resolve(text.trim());
        } else {
          reject(new Error('TXT file appears to be empty'));
        }
      };
      reader.onerror = () => reject(new Error('Failed to read TXT file'));
      reader.readAsText(file, 'utf-8');
    });
  } catch (error) {
    console.error('TXT parsing error:', error);
    throw new Error('Failed to read TXT file');
  }
};